GEMINI_MODELS = [

    "gemini-2.5-pro",

    "gemini-2.5-flash",

    "gemini-2.5-flash-lite",

    "gemini-2.0-flash",

    "gemini-1.5-pro",

    "gemini-1.5-flash"

]